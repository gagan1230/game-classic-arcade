// function for Enemies to set enemies x,y coordinates and their speed
var Enemy = function(x,y,speed) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.sprite = 'images/enemy-bug.png';
};
//update function for enemy
//dt is used as speed of differnet devices can be different but time remains constant for all PC's
Enemy.prototype.update = function(dt) {
    this.x = this.x + this.speed * dt;
    // Reset new speed 
    this.newspeed = 500;
    //enemy begin from x =0
    this.beginX = 0;
    if (this.x >= this.newspeed) {
        this.x = this.beginX;
        //random speed function is called
        //This means enemy starts with different speeds
        this.randomSpeed();
    }
    //checkcollision function is called
    //whenever player and enemy collide,game is reset
    this.checkCollision();
};

// Increase Speed using Math.random function
var speedIncrement = 30;
Enemy.prototype.randomSpeed = function (){
    /*math.floor inbuilt function is used to choose floor value in case math.random function
    generates decimal values
    )*/
    this.speed = speedIncrement * Math.floor(Math.random() * 10 + 1);
};

// Render method is used to draw the enemy on the screen
Enemy.prototype.render = function() {
   //here this.sprite is enemy.Its image is loaded in provided x,y coordinates
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
    ctx.fillStyle = "white";
 };
//whenever player collide bugs,game is reset
//so function to check collision
Enemy.prototype.checkCollision = function() {
    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var enemyBox = {x: this.x, y: this.y, width: 60, height: 70};
    if (playerBox.x < enemyBox.x + enemyBox.width &&
        playerBox.x + playerBox.width > enemyBox.x &&
        playerBox.y < enemyBox.y + enemyBox.height &&
        playerBox.height + playerBox.y > enemyBox.y) {
    
        //enemy's position is reset on collision.It again starts from grass and reach water
         player.characterReset();
    }
};

//  player starts at 200x and 400y
var Player = function() {
    this.startX = 200;
    this.startY = 300;
    this.x = this.startX;
    this.y = this.startY;
    this.sprite = 'images/char-pink-girl.png';
    
};

Player.prototype.update = function() {
    if (this.playerLives === 0) {
    reset();
    }
};

/* Resets the player position to the start position
reset event happens when player and enemy collide or player reaches water*/
Player.prototype.characterReset = function() {
    this.startX = 200;
    this.startY = 300;
    this.x = this.startX;
    this.y = this.startY;
};

Player.prototype.success = function() {
    this.characterReset();
};

// Draw the player on the screen
Player.prototype.render = function() {
  
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

//handleInput method() 
//navigate through top,bottom,up,down keys
Player.prototype.handleInput = function(allowedKeys) {
    switch (allowedKeys) {
        case "left":
            //at extreme left, move right
            if (this.x > 0) {
                this.x -= 101;
            }
            break;
        case "right":
            //at extreme right,otherwise move left
            if (this.x < 402) {
                this.x += 101;
            }
            break;
        case "up":
            //call success function if reached top
            if (this.y < 0) {
                this.success();
            } else {
                this.y -= 77;
            }
            break;
        case "down":
            if (this.y < 400) {
                this.y += 65;
            }
            break;
    }
};



// Now instantiate your objects.


// Instantiate player
var player = new Player();

// Empty allEnemies array
var allEnemies = [];

// Instantiate all enemies, set to 3, push to allEnemies array
for (var i = 0; i < 3; i++) {
    //startSpeed is a random number from 1-10 times speedMultiplier
    var startSpeed = speedIncrement * Math.floor(Math.random() * 10 + 1);
    //enemys start off canvas (x = -100) at the following Y positions: 60, 145, 230
    allEnemies.push(new Enemy(-100, 60 + (85 * i), startSpeed));
}




var input = function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };
    player.handleInput(allowedKeys[e.keyCode]);
};
document.addEventListener('keyup', input);

