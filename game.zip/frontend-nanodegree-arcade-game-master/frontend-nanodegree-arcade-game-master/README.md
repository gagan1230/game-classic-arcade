ARCADE GAME OF CLONES
This is a simple game in which a player avoids enemy in the game and using navigating keys move up,down,left or right to reach at top of canvas which is water and then player wins.

INSTALLATIONS
You can download the github repository provided in udacity course.
You will be provided with js in which you need to edit app.js to complete this project
Rest is already handled by resurces.js and engine.js

CONTRIBUTING
We will love to have contributions to this project,You can add score boards,count lives left of player and many more features.Start now

HOW TO PLAY THE GAME
1. You need to load 'index.html' using any web browser(google chrome,internet explore,mozilla firefox).
2. Avoid enemies and reach water
3. Use navigation keys to move.
4. On winning the game is reset




